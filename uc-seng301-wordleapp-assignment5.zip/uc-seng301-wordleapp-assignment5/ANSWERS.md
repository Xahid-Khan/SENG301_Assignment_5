# SENG301 Assignment 5 (2022) - Student answers

**YOUR NAME**

## Task 1 - Identify the patterns in the code

### Pattern 1

#### What pattern is it?

**YOUR ANSWER**

#### What is its goal in the code?

**YOUR ANSWER**

#### Name of UML Class diagram attached:

**YOUR ANSWER**

#### Mapping to GoF pattern elements:

| GoF element | Code element |
| ----------- | ------------ |
|             |              |


### Pattern 2

#### What pattern is it?

**YOUR ANSWER**

#### What is its goal in the code?

**YOUR ANSWER**

#### Name of UML Class diagram attached:

**YOUR ANSWER**

#### Mapping to GoF pattern elements:

| GoF element | Code element |
| ----------- | ------------ |
|             |              |


## Task 2 - Full UML Class diagram

### Name of file of full UML Class diagram attached

**YOUR ANSWER**


## Task 3 - Implement new feature

### What pattern fulfils the need for the feature?

**YOUR ANSWER**

### What is its goal and why is it needed here?

**YOUR ANSWER**

### Name of UML Class diagram attached:

**YOUR ANSWER**

### Mapping to GoF pattern elements:

| GoF element | Code element |
| ----------- | ------------ |
|             |              |


## Task 4 - BONUS - Acceptance tests for Task 4

### Feature file (Cucumber Scenarios)

**NAME OF FEATURE FILE**

### Java class implementing the acceptance tests

**NAME OF JAVA FILE**
